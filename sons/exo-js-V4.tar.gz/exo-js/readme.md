
# Exo Javascript : Pimp my Form

## Cibler le sélecteur
L'afficher dans la console

## Cibler les options du précédent sélecteur
Les afficher dans la console

## Cibler le formulaire 
L'afficher dans la console

## Créer un `<ul />` vide à la fin du formulaire (après le sélecteur)

## Lui ajouter un attibut identifiant `new-selector` 

## Pour chaque option, créer un `<li />` dans le `<ul />` précédent

## Chaque `<li />` doit avoir le même contenu que l'option correspondante

## Chaque `<li />` doit aussi avoir un attibut classe identique à l'option correspondante

## Chaque `<li />` doit aussi avoir un attibut `data-value` contenant la valeur de l'option correspondante

## Ajouter une couleur de police `greenyellow` au `<li />` de classe `cool`

## Ajouter une classe `rebeccapurple` au `<li />` précédent ce dernier `<li />` ciblé

## Ajouter une couleur de police `pink` au `<li />` de classe `cooler`

## Ajouter une couleur de fond `fuchsia` au `<li />` suivant le précédent `<li />` ciblé

## "Toggle" la classe `rebeccapurple` du dernier élément `<li />`