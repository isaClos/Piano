


let select = document.getElementById( 'selector' );
console.log( select.children );
console.log( select.childNodes );
console.log( select.firstElementChild );
console.log( select.lastElementChild );
console.log( select.firstElementChild.nextElementSibling );
console.log( select.lastElementChild.previousElementSibling );

// console.log( select );

// let selectBySelector = document.querySelector( '#selector' );
// console.log( selectBySelector );

// let selectByName = document.getElementsByName( 'selector' );
// console.log( selectByName );

let options = document.getElementsByTagName( 'option' );
// console.log( options );

let form = document.getElementById( 'pimp-my-form' );
// console.log( form );

let unordredList = document.createElement( 'ul' );
form.appendChild( unordredList );

// unordredList.id = 'new-selector';
unordredList.setAttribute( 'id', 'new-selector' );

for (let index = 0; index < options.length; index++) {
    
    let option = options[ index ];
    
    // console.log( option );

    let li = document.createElement( 'li' );
    li.innerHTML = option.innerHTML;

    let newClass = option.getAttribute( 'class' );
    
    // Avec une condition
    if( newClass !== null ) {
        li.setAttribute( 'class', newClass );
    }

    li.setAttribute( 'data-value', option.getAttribute( 'value' ) );
    
    /**
    * Effectue qqc au click
    * 
    * @param Event event 
    */
    li.addEventListener( 'click', function ( event ) {
        // console.log( event );
       
        // Ici this est le node courrant, celui sur lequel on a cliqué
        let myValue = this.getAttribute( 'data-value' );
   
        let optionElem = document.querySelector( `option[value="${myValue}"]` );
   
        // console.log( optionElem );

        // console.log( optionElem.selected );

        // On sélectionne l'option (cela désélectionne l'option précédente, car le select est à valeur unique)
        optionElem.selected = true;

        // console.log( optionElem.selected );
       
    } );

    select.style.display = 'none';

    /**
     * Equivalent à (fonction anonyme)
     * 
     * li.addEventListener( 'click', function() {
     *      // ici je fais quelque chose... 
     * } );
     * 
     * Equivalent à (fonction fléchée)
     * 
     * li.addEventListener( 'click', (e) => alert( e.target.innerHTML ) );
     */

    // Ou en ternaire...
    // li.setAttribute( 'class', newClass ? newClass : '' );

    unordredList.appendChild( li );

}

// let cool = document.querySelector( 'li.cool' );
// // console.log( cool );
// cool.style.color = 'greenyellow';

// let css3 = document.querySelector( 'li[data-value="CSS3"]' );
// console.log( css3 );
// // css3.setAttribute( 'class', 'rebeccapurple' ); // remplace les classes existantes

// css3.classList.add( 'rebeccapurple' );

// let cooler = document.querySelector( 'li.cooler' );
// cooler.style.color = 'pink';

// let php = document.querySelector( 'li[data-value="PHP"]' );
// console.log( php );
// // php.style.backgroundColor = 'fuchsia'; // le background inline surcharge tout le style css !! (poids 1000...)
// php.style.color = 'fuchsia';
// php.classList.toggle( 'rebeccapurple' );


// document.getElementById( 'mon-lien' ).addEventListener( 'click', function( event ) {
//     event.preventDefault();
//     console.log( event.pageX, event.pageY );
//     console.log( event.offsetX, event.offsetY );
//     console.log( event.x, event.y );
    
//     alert( 'le lien ne se propage plus !!' );
// } );


// let draggable = document.getElementById( 'draggable' );

// draggable.setAttribute( 'draggable', true );

// draggable.addEventListener( 'drag', function( event ) {
//     event.preventDefault();
//     this.classList.add( 'dragged' );
//     this.style.left = `${event.clientX}px`;
//     this.style.top = `${event.clientY}px`;
// } );


let myName = 'JuZ';

let myString = `
    <div class="name">
        ${myName}
    </div>
`;
 
// Equivalent en moche !
// let myString2 = '<div class="name">' + 
//         myName + 
//     '</div>'
// ;

console.log( myString );

let myContainer = document.createElement( 'div' );
myContainer.textContent = myString;

let body = document.querySelector( 'body' );

body.append( myContainer );